#[TUMBLOOK 3.0 THEME][demo]

**Please read all of the following information before installing.**

## General
1. **Read the license at the bottom of this file.** Please do not ever remove *all* credits from the theme.
	* If you alter the theme HTML in any way, you may edit the credit to read "Original theme by [Gabrielle Wee][e]" or something similar - a link to [Elletricity.com][e] is required.
	* *Do not distribute the original zip file on your own website, blog, or social network profile.*
2. **Do not remove the disclaimer.** I do not intend to deceive people into believing that they are visiting a Twitter profile. I am not responsible for what happens if you remove the disclaimer!
3. **Tumblook 3.0 has limited options.** Because of the nature of the theme, I have included relatively few options in comparison to previous themes. Tumblook 3.0 is intended to resemble a Facebook profile, and if I include more than the basic options, it will no longer fulfill that intention.
4. **Tumblook 3.0 does not exactly resemble Facebook.** I've used a different set of icons; the columns are slightly smaller and fold into a mobile-friendly layout. This is my own take on the Facebook profile, not a carbon copy.

If your question is not answered here, feel free to [contact me][e-contact], but please note that I may or may not be able to help you.

## Features
* Mobile, responsive layout
* Infinite scrolling
* Disqus integration
* Optional widgets - About, Following, Instagram, Flickr, Pinterest
* Two different types of highlighted posts
* Smart top bar that moves or becomes fixed based on your browser width and height
* Five different page layouts that mimic Facebook
	1. **Homepage, page 2, page 3, etc. (Facebook timeline)**
		* Full two-column layout with optional ask form
		* Cover photo section with customizable profile picture, title, and links
		* Twitter status integrated with posts
		* All widgets and description are displayed on the left
		* Bottom footer
	2. **Tag, search, and day pages (Facebook timeline)**
		* Same layout as the homepage
		* No photo or following widgets
	3. **Text, Quote, Chat, Link, and Answer permalink pages (individual post pages)**
		* Blue-tinted two-column layout
		* No cover photo/navigation section
		* Unified sidebar on the right
			* No photo or about widgets
			* "People You May Know" widget
			* Footer with all navigation links
	4. **Photo, Photoset, Audio, and Video permalink pages (individual photo pages)**
		* White-tinted two-column layout
		* No cover photo/navigation section
		* Sidebar broken up into sections
		* Bottom footer
	5. **Ask, Submit, 404, and other pages (About/Friends/Photos pages)**
		* One-column layout
		* Cover photo/navigation section
		* Large titles
		* Optional text before ask/submit forms
		* Bottom footer


## Widgets
* In order to enable comments, you must sign up for a [Disqus][d] account and set a shortname for your blog.
* Your [Flickr][f] ID is different from your Flickr username -  you can use [this site][fid] to find your ID.
* [Instagram][i] requires that you allow my app access to your basic information in order for the widget to display your photos. [Click here][iun] to allow access and find out your Instagram access token. Please note that you need both your username and access token for the widget to work properly.
* Note that [Pinterest][p] widget will display your latest nine *photo* pins and that it disregards boards.
* Your [Twitter][t] handle is all you need to enable the Twitter widget.

Each photo widget only displays the last nine photos, similar to the Faceebook photo section.

Except for the Twitter widget, all widgets are hidden when the browser window is shrunk past a certain width -or- your blog is viewed on a mobile device with a small width. This is meant to simplify the layout, which can be confusing at a small width, and I will not help you edit the theme to change this.

If your widget photos or latest tweet do not show up, this may be due to an incorrectly inputted ID/username or the other website's API.

## Tips
* Disable the optimized mobile layout to use Tumblook 3.0 on your mobile device. This option can be found on your Customize page under Advanced.
* You can disable the photo hovers (**Photo Zoom Links**) in your Appearance options.
* There is no way to ensure that the same blogs show up under any of the sections that show the people you follow.
* When uploading a custom profile picture, use a square image 160px wide or larger.
* If your blog is a shared one, you can show author icons next to each post by enabling **Show Group Authors** in your Appearance options.
* Try not to have too many page links or use long titles for pages - your navigation will flow over to the next line and ruin the look of the header. If you absolutely must have more pages, edit the extra page and uncheck the box for "Show a link to this page", then add it manually to your description.
* If you enable Ask and Submit buttons, they will show up in the bottom right corner of your cover photo like the message button on a real Facebook profile. **However, this means that they will not show up in your main navigation.**
* If you want to add text above your submit form, you must use the appearance option I've provided. ***Do not use the default Tumblr option in your settings*** - the text will show up outside of your post section. Also, when using HTML, use double quotes and not single quotes.

## Highlighted posts
* You can highlight a post with top and bottom striped borders - it will resemble a private Facebook post viewable only by you. Tag your post **x1** and **x2**. These need to be the first two tags on your post, or else an extra comma will show up after the tags on that post.
* You can highlight a post with a star bookmark, which is how Facebook displays featured posts. At the beginning of your tag section, use **x2** and **x3**.

## Install
This is the tutorial I've written on [my resource site][e-install] to install custom themes. You can [click here][e-install] to view the original tutorial with full-size images.

If you're using a operating system other than Mac, replace all instances of **⌘** with **Ctrl**.

1. Access your Customize page. You can get there either from your blog page or your Tumblr itself. Click on **Edit HTML**.
2. Click anywhere in the HTML and press **⌘ + A**, then **Delete**. This will remove your current theme.
3. Now, if you've had a theme with any sort of appearance options included, you must follow these next few steps. The Reset Defaults option is no longer functional, so you will need to reset options yourself. I've created a nifty "Clean Install" file that you can use to clear your theme. It looks like a Tumblr error page! Click [here][e-clean] to get the HTML. Highlight the HTML and press **⌘ + C**. *Be sure to only select the HTML, not the header at the top which includes a "Simple Sharing" button and the title of the page. If you do, it will leave some text at the top of your page that you do not want.*
4. Go back to your customize page. Click in the empty HTML box and press **⌘ + V**. Press the Update Preview button, wait for the page to reload, and then press **Save**.
5. **⌘ + C** the theme HTML of your choice. Go back to your customize page and reload/refresh. Click anywhere inside the HTML, press **⌘ + A** to highlight all of the text, and press **⌘ + V**. Update preview and save again. Don't worry if your theme looks unstyled - simply refresh the page and all your options and styling will be there!
6. Remember to click **Update Preview** before you save any further changes.

## Credits
* [Facebook.com][fb]
* [Foundation][cr-01] by Zurb (modified CSS)
* [Change element type plugin][cr-02] by Etienne Desautels
* [Tumblr like button][cr-03] by Matt Walton
* [imagesLoaded() plugin][cr-04] by David DeSandro
* [Resize plugin][cr-05] by Ben Alman
* [Colorbox plugin][cr-06] by Jack Moore (modified CSS)
* [Photoset plugin][cr-07] by Jonathan Moore (modified script)
* [Twitter plugin][cr-08] by seaofclouds.com (modified script)
* [Instagram plugin][cr-09] by Giovanni Cappellotto (modified script)
* [Flickr Feed plugin][cr-10] by Joel Sutherland (modified script)
* [Pinstagram RSS plugin][cr-11] by Marie Mosley (modified script)
* [Infinite Scrolling plugin][cr-12] by Paul Irish
* Icon font generated from [Fontello][cr-13]
	* [Entypo][cr-14] by Daniel Bruce

[cr-01]: http://foundation.zurb.com/
[cr-02]: https://gist.github.com/etienned/2934516/
[cr-03]: http://like-button.tumblr.com/
[cr-04]: https://github.com/desandro/imagesloaded/
[cr-05]: http://benalman.com/projects/jquery-resize-plugin/
[cr-06]: http://www.jacklmoore.com/colorbox/
[cr-07]: http://jonathanmoore.com/
[cr-08]: http://tweet.seaofclouds.com/
[cr-09]: http://potomak.github.io/jquery-instagram/
[cr-10]: http://www.gethifi.com/blog/a-jquery-flickr-feed-plugin/
[cr-11]: http://www.codeitpretty.com/2012/03/pinterest-gadget-for-blogger.html
[cr-12]: http://www.infinite-scroll.com/
[cr-13]: http://fontello.com/
[cr-14]: http://www.entypo.com/

## License

This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License][cc].

#### You are free:
* **to Share** — to copy, distribute and transmit the work
* **to Remix** — to adapt the work

#### Under the following conditions:
* **Attribution** — You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
* **Noncommercial** — You may not use this work for commercial purposes.
* **Share Alike** — If you alter, transform, or build upon this work, you may distribute the resulting work only under the same or similar license to this one.

#### With the understanding that:
* **Waiver** — Any of the above conditions can be [waived][cc-01] if you get permission from the copyright holder.
* **Public Domain** — Where the work or any of its elements is in the [public domain][cc-02] under applicable law, that status is in no way affected by the license.
* **Other Rights** — In no way are any of the following rights affected by the license:
	* Your fair dealing or [fair use][cc-03] rights, or other applicable copyright exceptions and limitations;
	* The author's [moral][cc-04] rights;
	* Rights other persons may have either in the work itself or in how the work is used, such as [publicity][cc-05] or privacy rights.

[demo]: http://tumblook-theme.tumblr.com/
[e]: http://elletricity.com/
[e-contact]: http://elletricity.com/contact/
[e-install]: http://elletricity.com/tutorials/custom-themes/
[e-clean]: http://cl.ly/MnYu
[fb]: http://facebook.com
[d]: http://disqus.com/
[f]: http://flickr.com/
[fid]: http://idgettr.com/
[i]: http://instagram.com
[iun]: http://elletricity.com/instagram/
[p]: http://pinterest.com/
[t]: http://twitter.com/
[cc]: http://creativecommons.org/licenses/by-nc-sa/3.0/deed.en_US
[cc-01]: http://creativecommons.org/licenses/by-nc-sa/3.0/deed.en_US#
[cc-02]: http://wiki.creativecommons.org/Public_domain
[cc-03]: http://wiki.creativecommons.org/Frequently_Asked_Questions#Do_Creative_Commons_licenses_affect_fair_use.2C_fair_dealing_or_other_exceptions_to_copyright.3F
[cc-04]: http://wiki.creativecommons.org/Frequently_Asked_Questions#I_don.E2.80.99t_like_the_way_a_person_has_used_my_work_in_a_derivative_work_or_included_it_in_a_collective_work.3B_what_can_I_do.3F
[cc-05]: http://wiki.creativecommons.org/Frequently_Asked_Questions#When_are_publicity_rights_relevant.3F